const { User, Message } = require('../models/models.js')
const jwt = require('jsonwebtoken')
const { Router } = require('express')
const { v4: uuidv4, stringify } = require('uuid');
const { Op } = require('sequelize')

const router = Router()

// ----------- print function ------------
function print(data1, data2) {
    if (data2 == undefined) {
        console.log('\n')
        console.log(data1)
        console.log('\n')
    } else {
        console.log('\n')
        console.log(data2)
        console.log(data1)
        console.log('\n')
    }
}

// ---------- view messages -------------
router.get('/', async function(req, res) {

    let messages = await Message.findAll({
        include: User
    })

    // ------ sending data to ejs rendered page ----------
    let data = {
        messages
    }

    res.render('index.ejs', data)
})

// ------------------ create page ---------------------
router.get('/createUser', function(req, res) {
    res.render('createUser.ejs')
})

// -------------- creation --------------------
router.post('/createUser', async function(req, res) {

    let { username, password } = req.body

    await User.create({
        username,
        password,
        role: "user"
    })

    res.redirect('/login')
})

//--------------- logging in page --------------------
router.get('/login', function(req, res) {
    res.render('login')
})

// -------------- logging in function -----------------
router.post('/login', async function(req, res) {

    let { username, password } = req.body

    let thisUser = await User.findOne({
        where: {
            [Op.and]: [
                { username },
                { password }
            ]
        }
    })

    if (thisUser) {

        // ------ jsonwebtoken sign ------------
        let data = {
            username: username,
            role: thisUser.role
        }

        let token = jwt.sign(data, "theSecret")

        res.cookie("token", token)

        res.redirect('/')
    } else {
        res.redirect('/error')
    }
})

// ------------ message page ---------------
router.get('/message', async function(req, res) {

    // --------- retrieving token from cookie -------
    let token = req.cookies.token

    // ------------ verifying token ---------
    let payload = await jwt.verify(token, "theSecret")

    // ---------- searching for user --------
    let user = await User.findOne({
        where: { username: payload.username }
    })

    // --------- passing data for the name tag on post message panel ---------- 
    data = {
        name: user.username
    }
    if (user) {
        res.render('message', data)
    } else {
        res.redirect('/login')
    }
})

// --------------- posting message ------------
router.post('/message', async function(req, res) {

    let { token } = req.cookies
    let { content } = req.body


    if (token) {

        // ----------verifing token ----------
        let payload = await jwt.verify(token, "theSecret")

        let user = await User.findOne({
            where: { username: payload.username }
        })

        // ------- id for each message -----------
        let id = uuidv4()

        await Message.create({
            content,
            UserId: user.id,
            Uid: id
        })

        res.redirect('/')
    } else {
        res.redirect('/createUser')
    }
})

// ------------- Likes function -----------------
router.post('/likes', async function(req, res) {

    // ----------- selecting Uid from message -----------
    let button = req.body
    let thisOne = Object.keys(button)

    let message = await Message.findOne({
        where: { Uid: thisOne }
    })

    // ------ incrementing likes count ------------
    if (message) {
        let count = message.likes
        if (count) {
            ++count
        } else {
            count = 1
        }

        //----------- updating likes -----------
        await Message.update({ likes: count }, {
            where: {
                Uid: thisOne
            }
        });

        res.redirect('/')
    } else {
        redirect('/')
    }

})

// ------------ error page ---------------
router.get('/error', function(req, res) {
    res.render('error')
})

router.all('*', function(req, res) {
    res.send('<h1 style="text-align: center;">This is Not Good</h1>')
})

module.exports = router