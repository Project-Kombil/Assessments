const express = require('express')
const app = express()

// -------------- Templating Engine --------------
app.set('view engine', 'ejs')

// --------------- Users List ------------------
app.get('/', function(req, res) {

    let data = {
        users: [{
                name: "Burt Lannister",
                age: 56,
                hobbies: ['reading', 'polo']
            },
            {
                name: "Tobe Nwige",
                age: 27,
                hobbies: ['writing', 'pressing flowers']
            },
            {
                name: "Miguel Atwood",
                age: undefined,
                hobbies: ['music', 'mediation']
            },
            {
                name: "Hieu Ngyen",
                age: 33,
                hobbies: undefined
            },
            {
                name: undefined,
                age: undefined,
                hobbies: undefined
            }
        ]
    }

    res.render('home', data)
})

app.listen(3333)
console.log(`Listening to PORT 3333`)