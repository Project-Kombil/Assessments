const express = require('express')
const app = express()

app.use(express.static(__dirname + "/public"))

// --------User Database-----------------
let users_data = []


// -----------------Index Route----------
app.get('/', function(request, response) {
    response.sendFile(__dirname + "/index.html")
})

// --------------Storing Data------------------
app.get('/createUser', function(request, response) {
    let user = {
        "First Name": request.query.f_name,
        "Last Name": request.query.l_name,
        book: request.query.book
    }
    users_data.push(user)
    response.status(201).redirect('/')
})

// ----------------- GET Results request-----------
app.get('/result', function(request, response) {

    // Array of All books from users_data
    let books = []
    let counts = {}

    for (let key of users_data) {
        books.push(key.book)
    }

    // Filtering Duplicated values into one Key/Value Pair
    for (let i = 0; i < books.length; i++) {

        if (counts[books[i]]) {

            counts[books[i]] += 1
        } else {
            counts[books[i]] = 1
        }
    }

    // Finding Highest Value 
    let max = 0
    let book = ""

    for (let key in counts) {
        if (counts[key] > max) {
            max = counts[key]
            book = key
        }
    }


    // Console Logged Entities
    console.log(counts)
    console.log(users_data)

    let data = JSON.stringify(`${book} is the most favored book that was read ${max} times!`)

    response.send(`<h1 style='text-align:center'>${data}</h1>`)
})

app.listen(4000)
console.log("\n Server Running on port 4000")