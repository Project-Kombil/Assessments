let initial_pic = document.getElementById('changed');
let cat_1 = document.getElementById('cat_1');
let cat_2 = document.getElementById('cat_2');
let cat_3 = document.getElementById('cat_3');

document.getElementById('cat_1').addEventListener("click",  function(){
    debugger
    let cat = cat_1.src;
    let swap = document.getElementById('cat_1').src = initial_pic.src;
        initial_pic.src = cat;
 
   });

document.getElementById('cat_2').addEventListener("click", function(){
    debugger
    let cat = cat_2.src;
    let swap = document.getElementById('cat_2').src = initial_pic.src;
        initial_pic.src = cat;
  
       
   });

document.getElementById('cat_3').addEventListener("click", function(){
    debugger
    let cat = cat_3.src;
    let swap = document.getElementById('cat_3').src = initial_pic.src;
        initial_pic.src = cat;
  
    
});