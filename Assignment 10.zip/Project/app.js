const express = require('express')
const app = express()
const cookieParser = require("cookie-parser")
const { v4: uuidv4 } = require('uuid');

// ------------ imported files ---------------------
const fake_db = require('./db.js')
const matchCredentials = require('./utils.js')

// -------------------- middleware -----------------
app.set('view engine', 'ejs')
app.use(cookieParser())
app.use(express.urlencoded({ extended: false }))
app.use(express.static('./public'));

// -------------- FORM Page -------------------
app.get('/', function(req, res) {
    res.render('pages/home')
})

//---------------- create a user account ------------------------ 
app.post('/create', function(req, res) {
    let body = req.body
    let user = {
        username: body.username,
        password: body.password
    }
    fake_db.users[user.username] = user
    console.log(fake_db)

    res.setTimeout(2000, function() {
        res.redirect('/')

    })
})

// ------------- Login Page ----------------------
app.get('/loginPage', function(req, res) {
    res.render('pages/loginPage')
})

// ------------------ login ---------------------------
app.post('/login', function(req, res) {
    if (matchCredentials(req.body)) {
        let user = fake_db.users[req.body.username]
            // this creates a random id that is,
            // for all practical purposes,
            // guaranteed to be unique. We’re
            // going to use it to represent the
            // logged in user, and their session

        let id = uuidv4()
            // create session record
            // Use the UUID as a key
            // for an object that holds
            // a pointer to the user
            // and their time of login.
            // If we have any data that we
            // want to hold that doesn’t belong in
            // database, can put it here as well.
        fake_db.sessions[id] = {
                user: user,
                timeOfLogin: Date.now()
            }
            // create cookie that holds the UUID (the Session ID)
        res.cookie('SID', id, {
            expires: new Date(Date.now() + 900000),
            httpOnly: true
        })
        console.log(fake_db)

        res.setTimeout(2500, function() {
            res.render('pages/loggedIn')
        });
    } else {
        res.redirect('/error')
    }
})

//---------------- delete session and cookie ------------------------ 
app.get('/delete', function(req, res) {

    // ----------- Deleting Session -----------------
    let id = req.cookies.SID
    delete fake_db.sessions[id]

    // -------------- Deleting Cookie ---------------
    res.cookie('SID', '', {
        maxAge: 0,
        httpOnly: true
    })

    res.render('pages/loginPage')
})

//--------------- this is the protected route ----------------
app.get('/supercoolmembersonlypage', function(req, res) {

    let id = req.cookies.SID
    let session = fake_db.sessions[id]

    if (session) {
        res.render('pages/members')
    } else {
        res.render('pages/error')
    }
})

// --------------- if something went wrong, you get sent here -----------
app.get('/error', function(req, res) {
    res.render('pages/error')
})

// ------------------ 404 handling --------------------
app.all('*', function(req, res) {
    res.render('pages/error')
})

app.listen(1612)
console.log('\nListening on PORT 1612')