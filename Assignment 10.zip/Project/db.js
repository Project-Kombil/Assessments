const fake_db = {
    users: {},
    sessions: {}
}
module.exports = fake_db