const { User, Message } = require('../models/models.js')
const jwt = require('jsonwebtoken')
const { Router } = require('express')

const router = Router()

// ----------- print function ------------
function print(data1, data2) {
    if (data2 == undefined) {
        console.log('\n')
        console.log(data1)
        console.log('\n')
    } else {
        console.log('\n')
        console.log(data2)
        console.log(data1)
        console.log('\n')
    }
}

// ---------- view messages -------------
router.get('/', async function(req, res) {

    let messages = await Message.findAll({
        include: User
    })
    let data = { messages }
    console.log(data)
    console.log(messages)

    res.render('index.ejs', data)
})

// ------------------ create page ---------------------
router.get('/createUser', function(req, res) {
    res.render('createUser.ejs')
})

// -------------- creation --------------------
router.post('/createUser', async function(req, res) {

    let { username, password } = req.body

    try {
        await User.create({
            username,
            password,
            role: "user"
        })
    } catch (e) {
        console.log(e)
    }

    res.redirect('/login')
})

//--------------- logging in page --------------------
router.get('/login', function(req, res) {
    res.render('login')
})

// -------------- logging in function -----------------
router.post('/login', async function(req, res) {

    let { username, password } = req.body
    let user

    try {
        user = await User.findOne({
            where: { username }
        })
    } catch (e) {
        console.log(e)
    }

    if (user && user.password === password) {
        let data = {
            username: username,
            role: user.role
        }

        let token = jwt.sign(data, "theSecret")

        res.cookie("token", token)

        res.redirect('/')
    } else {
        res.redirect('/error')
    }
})

router.get('/message', async function(req, res) {
    let token = req.cookies.token

    let payload = await jwt.verify(token, "theSecret")

    // ---------- searching for user --------
    let user = await User.findOne({
        where: { username: payload.username }
    })

    data = {
        name: user.username
    }
    if (user) { // update: not too good but main concept of jwt taken
        res.render('message', data)
    } else {
        res.redirect('/login')
    }
})

// --------------- posting message ------------
router.post('/message', async function(req, res) {

    let { token } = req.cookies
    let { content } = req.body


    if (token) {

        // ----------verifing token ----------
        let payload = await jwt.verify(token, "theSecret")

        let user = await User.findOne({
            where: { username: payload.username }
        })

        await Message.create({
            content,
            UserId: user.id
        })

        res.redirect('/')
    } else {
        res.redirect('/createUser')
    }
})

router.get('/error', function(req, res) {
    res.render('error')
})

router.all('*', function(req, res) {
    res.send('404 dude')
})

module.exports = router