const { Sequelize, Model, DataTypes, Op } = require('sequelize');
const sequelize = new Sequelize('sqlite::memory:');
const express = require('express')
const app = express()
const cookieParser = require("cookie-parser")
const { v4: uuidv4 } = require('uuid');

// ------------ imported files ---------------------
const User = require('./User_class.js')
const Session = require('./Session_class.js')

// -------------------- middleware -----------------
app.set('view engine', 'ejs')
app.use(cookieParser())
app.use(express.urlencoded({ extended: false }))
app.use(express.static('./public'));

// -------------- FORM Page -------------------
app.get('/', function(req, res) {
    res.render('pages/home')
})

//---------------- create a user account ------------------------ 
app.post('/create', async function(req, res) {

    User.init({
        username: DataTypes.STRING,
        password: DataTypes.STRING,
    }, { sequelize, modelName: 'user' });

    let body = req.body;

    // ------ creating user -----------
    await User.sync();
    const user = await User.create({
        username: body.username,
        password: body.password
    });

    console.log('\nCreated User')
    console.log(user.toJSON())

    res.setTimeout(1500, function() {
        res.redirect('/')
    })
})

// ------------- Login Page ----------------------
app.get('/loginPage', function(req, res) {
    res.render('pages/loginPage')
})

// ------------------ login ---------------------------
app.post('/login', async function(req, res) {

    let body = req.body

    // --------- Matching ----------------
    await User.sync()
    const thisUser = await User.findOne({
        where: {
            [Op.and]: [
                { username: body.username },
                { password: body.password }
            ]
        }
    })

    if (thisUser == null) {
        res.redirect('/error')
    } else {

        Session.init({
            SID: DataTypes.STRING,
            username: DataTypes.STRING,
            password: DataTypes.STRING,
            timeOfLogin: DataTypes.DATE
        }, { sequelize, modelName: 'session' });

        // ---------- session setting ---------
        let id = uuidv4()

        await Session.sync()
        await Session.create({
            SID: id,
            username: body.username,
            password: body.password,
            timeOfLogin: Date.now()
        })

        // create cookie that holds the UUID (the Session ID)
        res.cookie('SID', id, {
            expires: new Date(Date.now() + 900000),
            httpOnly: true
        })

        res.setTimeout(1600, function() {
            res.redirect('/supercoolmembersonlypage')
        })
    }
})

//--------------- this is the protected route ----------------
app.get('/supercoolmembersonlypage', async function(req, res) {

    let id = req.cookies.SID

    // ------ checking for undefined values -------
    if (id == undefined) {
        res.redirect('/error')
    } else {

        // -------- if no undefined ----------
        await Session.sync()
        const user = await Session.findOne({
            where: {
                SID: id
            }
        })

        if (user == null) {
            res.redirect('/error')
        } else {
            res.render('pages/members')
        }
    }

})


//---------------- delete session and cookie ------------------------ 
app.get('/delete', async function(req, res) {

    // ----------- Deleting Session -----------------
    let id = req.cookies.SID

    if (id == undefined) {
        res.redirect('pages/error')

    } else {

        await Session.sync();
        const user = await Session.findOne({
            where: { SID: id }
        });

        user.destroy()

        // -------------- Deleting Cookie ---------------
        res.cookie('SID', '', {
            maxAge: 0,
            httpOnly: true
        })

        res.render('pages/loginPage')
    }
})

// --------------- if something went wrong, you get sent here -----------
app.get('/error', function(req, res) {
    res.render('pages/error')
})

// ------------------ 404 handling --------------------
app.all('*', function(req, res) {
    res.render('pages/error')
})


app.listen(1612)
console.log('\nListening on PORT 1612')